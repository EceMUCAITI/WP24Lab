package mk.finki.ukim.mk.lab.service;


public class EventBookingServiceImpl {
}
